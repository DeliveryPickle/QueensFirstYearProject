function $(id) { return document.getElementById(id); }//Quick access the element
function notify() {//send a notification
  var opt = {
    type: "list",
    title: "Notification",
    message: "msg",
    iconUrl: "img/icon.png",
    items: [{ title: "", message: "An alternative product was found" }]
  }
  chrome.notifications.create('', opt, function (id) { })
}
function tabsearch() {
  var fourmTabs = new Array();
  chrome.tabs.query({}, function (tabs) {
    for (var i = 0; i < tabs.length; i++) {
      fourmTabs[i] = tabs[i];
    }
    for (var i = 0; i < fourmTabs.length; i++) {
      if (fourmTabs[i] != null) {
        //window.console.log(fourmTabs[i]);
        //window.console.log(fourmTabs[i].title);
        if (fourmTabs[i].title.indexOf("Amazon") != -1) { notify(); }
      }
      else {
        window.console.log("??" + i);
      }
    }
  });
} 

//main body
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) { //active when a new tab was open or change
  if (changeInfo.status != 'complete')
    return;
  if (tab.url.indexOf('amazon.ca') != -1) {//index search of url, can be change to the title search
    //chrome.tabs.executeScript(tabId, {code: 'alert(1)'});//alert on the change tab
    //alert(productprice);
    chrome.tabs.executeScript(tab.ib, {
      file: 'inject.js'
    });
    chrome.storage.sync.get(['alternative'], function (data) {
      if (data.alternative){
        notify()
        chrome.storage.sync.set({'alternative':false});
      }
    });
  };
});