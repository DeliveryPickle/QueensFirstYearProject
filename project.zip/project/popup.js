//Javascript to contol the popup elemments
var productname="0";//input the name of the product
var productpic="img/product.jpg";//input pic url of the product
var productprice="0";//input price of the product
var producturl="www.amazon.com";//input link of the product

//product inforamtion functions
function ProductName() { document.getElementById('information').innerHTML = "Name:" + productname; }
function ProductImage() { var element = document.getElementById('productimage'); element.src = productpic; }
function ProductPrice() { document.getElementById('productprice').innerHTML = "Price:$" + productprice; }
//ctrl context
function announcement(words) { document.getElementById('annoucement').innerHTML = words; }
function hideask() {
  document.getElementById('Button1').style.display = 'none';
  document.getElementById('Button2').style.display = 'none';
  document.getElementById('question').style.display = 'none';
}
function openurl() { open(producturl); }
//button functions
function ButtonYes() { announcement("Thank you for your feed back."); hideask(); }
function ButtonNo() { announcement("We will improve our extension."); hideask(); }
//alt functions
function test(testvalue) { document.getElementById('test').innerHTML = "Value:" + testvalue; }//test the value


ProductName();
ProductImage();
ProductPrice();
var yesButton = document.getElementById("Button1");
var noButton = document.getElementById("Button2");
yesButton.addEventListener("click", ButtonYes);
noButton.addEventListener("click", ButtonNo);
var picclick = document.getElementById("productimage");
picclick.addEventListener("click", openurl);

function updatePopup() {
  chrome.storage.sync.get(['name', 'price','url','picture'], function (data) {
      document.getElementById("productprice").innerText = '$' + data.price;
      document.getElementById('information').innerHTML = "Alternative: " + data.name;
      document.getElementById('productimage').src = data.picture;
      producturl = data.url;
  });
}    
document.addEventListener('DOMContentLoaded', updatePopup);