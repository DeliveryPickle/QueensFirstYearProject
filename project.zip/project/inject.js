// this is the code which will be injected into a given page...

(function() {

	// just place a div at top right
	var div = document.createElement('div');
	div.style.position = 'fixed';
	div.style.top = 0;
	div.style.right = 0;
	div.textContent = 'Injected!';
	document.body.appendChild(div);

    function newItem(itemName, itemAliases) {
        return {
            name: String(itemName),
            aliases: itemAliases,
            // aliases is expected to be an array.
        }
    }

    let itemBattery = newItem("Battery", ["battery","batteries"]);
    let itemPaperTowel = newItem("Paper Towel", ["paper towel"]);
    let itemDishDetergent = newItem("Dishwasher Detergent", ["dishwasher detergent", "dish detergent"]);
    let itemHandSoap = newItem("Hand Soap", ["hand soap"]);
    let itemPen = newItem("Pen", ["pen","pens"]);
    let storedProductName = ''

    //if (document.getElementById("productTitle") == true){
    //    storedProductName = document.getElementById("productTitle").textContent;
    //};
    storedProductName = document.getElementById("productTitle").textContent;
    function checkTitleForItem(itemToCheck) {
        for(const alias of itemToCheck.aliases) {
            if(new RegExp(String(alias), "i").test(storedProductName)) {
                return(true);
            }
        }
        return(false);
    }
    //database
    var battery = [{"category":"Battery",
    "price":"17.89",
    "url":"https:\/\/www.amazon.ca\/Energizer-Universal-Rechargeable-Batteries-Pre-Charged\/dp\/B009NEKAHM\/ref=sr_1_5?crid=R5B21ZYH7OGZ&dchild=1&keywords=energizer%2Brechargeable%2Bbatteries&qid=1612535713&sprefix=energizer%2Caps%2C173&sr=8-5&th=1",
    "picture": "https://images-na.ssl-images-amazon.com/images/I/81e8%2BqcadcL._AC_SL1500_.jpg",
    "tag":"Alt Battery"},{"category":"Battery","price":"17.9a","url":"abc","tag":"Alt Battery2"}];

    var pens = [{"category":"Pens",
    "price":"28.43",
    "url":"https:\/\/www.amazon.ca\/STABILO-GREENpoint-Recycled-1-1mm-0-8mm\/dp\/B004D36PL8\/ref=sr_1_1?dchild=1&keywords=Stabilo%C2%AE+GREENpoint%C2%AE&qid=1612570583&sr=8-1",
    "picture": "https://images-na.ssl-images-amazon.com/images/I/81S8hSYAzoL._AC_SL1500_.jpg",
    "tag":"Alt Pens"}];

    var paperTowel = [{"category":"Paper Towel",
    "price":"25.00",
    "url":"https:\/\/www.amazon.ca\/Cascades-Enviro-Paper-Towels-Sheets\/dp\/B081XZDL3Z\/ref=sr_1_1?dchild=1&keywords=Roll+Paper+Towels+cascade&qid=1612568058&sr=8-1",
    "picture": "https://images-na.ssl-images-amazon.com/images/I/71K08RxN1KL._AC_SL1500_.jpg",
    "tag":"Alt Paper"}];

    var soap = [{"category":"Hand Soap",
    "price":"8.99",
    "url":"https:\/\/www.amazon.ca\/NATURE-CLEAN-Liquid-Hand-Soap\/dp\/B0165XIU0W\/ref=sr_1_2?dchild=1&keywords=nature+clean+soap&qid=1612569930&sr=8-2",
    "picture":"https://images-na.ssl-images-amazon.com/images/I/71QllsLUotL._AC_SL1500_.jpg",
    "tag":"Alt Hand"}];

    var detergent = [{"category":"Dishwasher Detergent",
    "price":"24.99",
    "url":"https:\/\/www.amazon.ca\/Nellies-Natural-Automatic-Dishwasher-Powder\/dp\/B001GQU9US\/ref=sr_1_7?dchild=1&keywords=nellies&qid=1612569269&sr=8-7",
    "picture": "https://images-na.ssl-images-amazon.com/images/I/61Idh6SGLVL._AC_SL1500_.jpg",
    "tag":"Alt Dish"}];

    items = [itemBattery, itemPaperTowel, itemDishDetergent, itemHandSoap, itemPen]
    function determine(output){
        if (output == itemBattery){
            return battery
        } else if (output == itemPaperTowel){
            return paperTowel
        } else if (output == itemDishDetergent){
            return detergent
        } else if (output == itemHandSoap){
            return soap
        } else if (output == itemPen){
            return pens
        }
    };
    for (i=0; i< items.length; i++){
        if (checkTitleForItem(items[i])){
            currentProduct = determine(items[i]);
            var product = JSON.stringify(currentProduct);
            var product = JSON.parse(product)[0];
            chrome.storage.sync.set({'name':product.category, 'price':product.price, 'url':product.url,'picture':product.picture,'alternative':true});
        }
    }

})();